<?php return array (
    'parameters' =>
        array (
            'database_host' => '127.0.0.1',
            'database_port' => '',
            'database_name' => 'prestashop',
            'database_user' => 'root',
            'database_password' => 'password',
            'database_prefix' => 'ps_',
            'database_engine' => 'InnoDB',
            'mailer_transport' => 'smtp',
            'mailer_host' => '127.0.0.1',
            'mailer_user' => NULL,
            'mailer_password' => NULL,
            'secret' => 'Mf6zkVBCg695Tw7hYOTHBEWQEpdNLd1jonigbi3EQh0aI1857czKDwN3MpecM4Pp',
            'ps_caching' => 'CacheMemcache',
            'ps_cache_enable' => false,
            'ps_creation_date' => '2021-07-12',
            'locale' => 'en-US',
            'use_debug_toolbar' => true,
            'cookie_key' => 'cw399s5jwV58Wbz2VvIx5DjKBiu54pAP5YvAOasWAOwDo1REWXZLW6QncnjnNOfk',
            'cookie_iv' => '8hw6IbWVusjdPSgUWOgoGMgaSGCFqm5E',
            'new_cookie_key' => 'def00000a92a6f83ac259b6d7e5353a35a2af33614b268a8b781e4a4d8fcf2b658571b1a9ce281eb9916afdcf1d39359e439741a3f749f90c3db3f7d1c546328e14c508c',
            'api_public_key' => '-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAt7051COt+l79vlOO56/G
AEUL3VeF8QvQo5uqIIUTpYbnu/Vabmq2PVKeEr191V/1lY6Wf9o406qfNc2dys+9
5jRTBWKXTsAtZE+fry2j9Pm0sdHSQTsUSJUQkKSevixFOTFW+o8N8NhGCY+/xGzB
3nv+tw8rl2iSZols4hWS5nJX56yQvu7N6B2cakkhMvUEi4tPnLGi2f72FSaVSgSi
Ma5J4ukWXiDcMbIYM0Ks1FnPEUtQEbqw9btYrrG7PRt/AmNQzLqdtkRToA6oKhTs
uAzb34jIhb5/qd3Z1fQseVLnTJuPIg2W7U8H+L7lNSOQ8s7gaxxongEYDXZFN+BA
4wIDAQAB
-----END PUBLIC KEY-----
',
            'api_private_key' => '-----BEGIN PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQC3vTnUI636Xv2+
U47nr8YARQvdV4XxC9Cjm6oghROlhue79VpuarY9Up4SvX3VX/WVjpZ/2jjTqp81
zZ3Kz73mNFMFYpdOwC1kT5+vLaP0+bSx0dJBOxRIlRCQpJ6+LEU5MVb6jw3w2EYJ
j7/EbMHee/63DyuXaJJmiWziFZLmclfnrJC+7s3oHZxqSSEy9QSLi0+csaLZ/vYV
JpVKBKIxrkni6RZeINwxshgzQqzUWc8RS1ARurD1u1iusbs9G38CY1DMup22RFOg
DqgqFOy4DNvfiMiFvn+p3dnV9Cx5UudMm48iDZbtTwf4vuU1I5DyzuBrHGieARgN
dkU34EDjAgMBAAECggEAf+2SG/ATrCUDSsbm0s2BcKKiViQgL+poA+HYG/hL6434
PtffdM17wUqKoMWqnSvI066Jfs8zjbxYSZ+144Ws1GFOBIvWiZAoipUdu1xtsZ1C
gCR03dICl16iP/M+S26La/y8cIu1yyDp8rJRdLO8b+mpOU+orCy08gtw8iDPPP7l
zHhNene33xO9K/BS0eVbwBXwlGayLmH3naTewqVkfp3FzWFEB3aNeyDryp7fN8ca
m2/iW8KKlKzl+bZ+CRZN8wGjZL0sjcP1W+kzxvQxCeQXTSB7LhM2XvF61tNqIBDm
hEfWvoG4wTrM0SEuf86smgNByw6hiGcr3ARcokpg4QKBgQDanAkHDYe9izm0VtV3
DJs8uPIf4AHraEVbbii5tOy+prxcb2MkWmys/ghQbzMmhxycr9HW9lLRovLGhxeh
5CGb6fkLXUu3Dxl7IerUk4Uk8x8SFw4Y2S5WWjIDIQTIkn0QIy2PuqbxWNo/ZJIs
OiV7taDT/CoBv0UHC8PtMZv5qQKBgQDXKl5w75HYtCq9yXoFw/d6ZEz+iE0Sfntr
R98Cgnoyt0PnTpzFhTWzEbIoMvNzjF1l5FPRTbyZDXcJqa5GdQPERqhrnf7x5u6B
dz9Ox3kJOvPz8ZIUY0oyqDyqU8YU4JdCaeyYTmjtwduK1O3maE8gsQMHj9UUMLKj
u59Jl0y1qwKBgBQheEdY/J38uySbNm8PDyCJW2qKA0M9R93CiCeJvJ9V1VShwTxw
wz8u6W8WvlwW5xCatDUaW8gIPFkBybBTxLCJ3DAquDU0Q8Ft/yTyLLmZVcwhqV+q
aDT1e1OEb99UdgXNZ32rz4G8D+T0iu1dsWPx9sxulSOyDFY4xCMMhXN5AoGBAIaQ
pe3ltoYb75swVVMjwzPVZN3PKryFQ/TNRyjPp1LukNYpsRxK+lGaoJxJeT5rq8Hc
sZr2Dhx+clMlvqur5QYs1oovjtGFBucLSBmh4Q2nxAhtrVl421+hHge8Sualq5PK
oUCD0VXY5tAF6R8vX0Vnzyg8iRuOdTq3TaB9smjvAoGAbgypIUPilY/5aUVT3GuK
58qob/qzixaQeuk9/kjN0dvRUqkAUQ5WCYL1drOzj2zFay0hjUGoIZ5UwDixjvbI
bj0qsVWs5bShy+QCbc5QD0cnECEm1YsTosyrUsjfBz47zzSbxnu8YoKQfXDJ24Jz
y8JR3k1WPeuuoUpTLKM1C/8=
-----END PRIVATE KEY-----
',
        ),
);
